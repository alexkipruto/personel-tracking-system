﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PTS.Models.Chart
{
    public class DashChartModel
    {
        public string PersonnelFullName { get; set; }
        public int AssigmentCount { get; set; }
    }
}
