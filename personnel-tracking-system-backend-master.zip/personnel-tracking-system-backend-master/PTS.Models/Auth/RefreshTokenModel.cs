﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PTS.Models.Auth
{
    public class RefreshTokenModel
    {
        public string Token { get; set; }
    }
}
