# personnel-tracking-system-backend

A project where you can assign tasks to staff and send them notifications
