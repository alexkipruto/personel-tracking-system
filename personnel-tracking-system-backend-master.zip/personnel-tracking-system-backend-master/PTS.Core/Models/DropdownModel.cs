﻿using PTS.Core.Signatures;

namespace PTS.Core.Models
{
    public class DropdownModel:IBaseModel
    {
        public int Id { get; set; }
        public string Description { get; set; }
    }
}
