﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PTS.Core.Signatures
{
    public interface IBaseModel
    {
        int Id { get; set; }
    }
}
