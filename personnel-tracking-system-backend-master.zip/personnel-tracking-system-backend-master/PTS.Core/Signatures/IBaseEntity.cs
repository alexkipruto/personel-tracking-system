﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PTS.Core.Signatures
{
    public interface IBaseEntity
    {
        int Id { get; set; }
    }
}
