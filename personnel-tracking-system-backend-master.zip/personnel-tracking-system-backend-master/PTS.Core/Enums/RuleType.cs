﻿namespace PTS.Core.Enums
{
    public enum RuleType
    {
        Null = 0,
        View = 1,
        Insert = 2,
        Update = 3,
        Delete = 4
    }
}
