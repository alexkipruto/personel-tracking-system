﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PTS.Core.Messages
{
    public static class EmailMessage
    {
        public static string SentSuccessfully => "Mail başarıyla gönderildi";
    }
}
