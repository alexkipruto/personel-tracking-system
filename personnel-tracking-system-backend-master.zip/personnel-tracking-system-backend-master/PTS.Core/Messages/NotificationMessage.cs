﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PTS.Core.Messages
{
    public static class NotificationMessage
    {
        public static string Title => "Görev Oluşturuldu";
        public static string Message => "Sistem tarafından size yeni bir görev oluşturuldu";
    }
}
